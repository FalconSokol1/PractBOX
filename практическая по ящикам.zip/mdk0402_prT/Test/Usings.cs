using Microsoft.VisualStudio.TestTools.UnitTesting;
using Prac1_MDK0402;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prac1_MDK0402.Tests
{
    [TestClass()]
    public class ProgramTests
    {
        [TestMethod()]
        public void Test()
        {
            Assert.Fail();
        }
    }
}